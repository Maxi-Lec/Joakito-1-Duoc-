/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inventariotienda;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
/**
 *
 * @author AL-Alumno
 */
public class InventarioTienda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<String> productos = new ArrayList<>();
        productos.add("Fideos");
        productos.add("Arroz");
        productos.add("Pan");
        productos.add("Leche");
        productos.add("Huevos");
        System.out.println("Lista inicial:" + productos);
        
        productos.set(0, "Mantequilla");
        System.out.println("Tras aplicar set():" + productos);
        
        int indicePan = productos.indexOf("Pan");
        System.out.println("El indice de Pan es:" +  indicePan);
        
        String productosAEliminar = "Leche";
        if (productos.contains(productosAEliminar)) {
            productos.remove(productosAEliminar);
            System.out.println("Producto" + productosAEliminar + "eliminado correctamente");
        } else {
            System.out.println("Aviso: El producto" + productosAEliminar + "no existe en el inventario");
        }
        System.out.println("Total de productos restantes:" + productos.size());
        System.out.println("\n--- Inventario final ordenado ---");
        Collections.sort(productos);
        for(int i = 0; i< productos.size(); i++) {
            System.out.println((i + i)+ ". " + productos.get(i));
        }
    }
    
}
