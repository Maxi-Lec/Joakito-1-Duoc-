/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mascotavirtual;

/**
 *
 * @author AL-Alumno
 */
public class MascotaVirtual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // crear mascota
        Mascota mascota = new Mascota("Firualais");
        
        // estado inicial
        System.out.println("=== ESTADO INCIAL ===");
        mascota.mostrarEstado();
        
        // jugar 3 veces
        System.out.println("=== JUGANDO 3 VECES ===");
        
        mascota.jugar();
        mascota.jugar();
        mascota.jugar();
        
        // mostrar estado
        mascota.mostrarEstado();
        
        // ver si sigue feliz
         System.out.println("¿Sigue feliz?" + mascota.estaFeliz());
         
         // recuperar energia 
         System.out.println("=== LA MASCOTA VA A DORMIR ===");
         mascota.dormir();
         
         //estado final
         mascota.mostrarEstado();
    }
    
}
