/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mascotavirtual;

/**
 *
 * @author AL-Alumno
 */
public class Mascota {
    // atributos
    private String nombre;
    private int energia;
    private int hambre;
    
    // constructor

    public Mascota(String nombre) {
        this.nombre = nombre;
        this.energia = 100;
        this.hambre = 0;
    }
    // comer
    public void comer(){
        hambre = hambre -30;
        
        if (hambre < 0){
            hambre = 0;
        } 
    }
    
     // jugar
    public void jugar(){
        energia = energia -20;
        hambre = hambre +15;
    }
    
    //dormir
    public void dormir(){
            energia = 100;
    }
    // ver si la mascota esta feliz
    public boolean estaFeliz(){
        return energia > 50 && hambre <  50;
    }
    // mostrar estado
    public void mostrarEstado(){
        System.out.println("Nombre" + nombre);
        System.out.println("Energia" + energia);
        System.out.println("Hambre" + hambre);
        System.out.println("¿Esta feliz?" + estaFeliz());
    }
        
    
}
