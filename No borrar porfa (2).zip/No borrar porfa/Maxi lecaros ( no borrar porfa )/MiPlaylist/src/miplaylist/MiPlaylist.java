/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package miplaylist;

/**
 *
 * @author AL-Alumno
 */
public class MiPlaylist {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // canciones
        Cancion c1 = new Cancion("Todo un palo", "Patricio rey y sus redonditos de ricota", 420);
        Cancion c2 = new Cancion("Pornomiseria", "Hesse Kassel", 840);
        Cancion c3 = new Cancion("Nupcial", "Cicuta", 300);
        Cancion c4 = new Cancion("RICHARD MILLE", "EL BAI , Piero 47", 180);

        System.out.println("--- Mi Top 3 de Canciones ---");
        c1.mostrar();
        c2.mostrar();
        c3.mostrar();
        c4.mostrar();

        // cambiar duracion
        System.out.println("\n--- Cambiando duración de la canción 2 ---");
        c2.setDuracionSeg(260); // Se cambia de 185 a 260 segundos 
        c2.mostrar();
    }

 }
    

