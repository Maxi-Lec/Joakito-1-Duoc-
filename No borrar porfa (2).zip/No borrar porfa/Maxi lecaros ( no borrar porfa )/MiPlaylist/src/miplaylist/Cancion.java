/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package miplaylist;

/**
 *
 * @author AL-Alumno
 */
public class Cancion {
    private String titulo;
    private String artista;
    private int duracionSeg;

    // 1. Dos constructores: vacío y con parámetros
    public Cancion() {
    }

    public Cancion(String titulo, String artista, int duracionSeg) {
        this.titulo = titulo;
        this.artista = artista;
        this.duracionSeg = duracionSeg;
    }

    // 2. esLarga(): true si dura más de 240 segundos
    public boolean esLarga() {
        return this.duracionSeg > 240;
    }

    // 3. duracionFormato(): usa / y % para formato mm:ss
    public String duracionFormato() {
        int minutos = this.duracionSeg / 60;
        int segundos = this.duracionSeg % 60;
        
        // Operador ternario para agregar un "0" a los segundos si son menores a 10
        String segFormato = (segundos < 10) ? "0" + segundos : String.valueOf(segundos);
        
        return minutos + ":" + segFormato;
    }

    // Método mostrar(): Imprime siguiendo el formato de ejemplo de la imagen
    public void mostrar() {
        String etiquetaLarga = esLarga() ? " [larga]" : "";
        System.out.println(this.titulo + " - " + this.artista + " (" + duracionFormato() + ")" + etiquetaLarga);
    }

    // Getter y Setter (Necesario para el punto 5)
    public int getDuracionSeg() {
        return duracionSeg;
    }

    public void setDuracionSeg(int duracionSeg) {
        this.duracionSeg = duracionSeg;
    }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getArtista() { return artista; }
    public void setArtista(String artista) { this.artista = artista; }
}

