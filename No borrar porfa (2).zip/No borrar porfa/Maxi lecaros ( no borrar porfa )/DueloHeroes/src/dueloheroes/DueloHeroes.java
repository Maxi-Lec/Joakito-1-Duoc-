/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dueloheroes;

/**
 *
 * @author AL-Alumno
 */
public class DueloHeroes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // crear los heroes
        Heroe a = new Heroe("Valkiria",100,10);
        Heroe b = new Heroe("Golem",130,12);
        
        System.out.println("=== DUELO DE HEROES ===");
        System.out.println(a.getNombre()+ " vs " + b.getNombre());
        System.out.println();
        
        //pelea
        while (a.estaVivo() && b.estaVivo()){
            
            // a ataca a b
            a.atacar(b);
            
            // contra ataque 
            if (b.estaVivo()){
                b.atacar(a);
            }
            
            System.out.println();
        }
        
        //mostrar ganador
        System.out.println("=== FIN DEL COMBATE ===");
        
        if (a.estaVivo()){
            System.out.println(" gano " + a.getNombre()+ " felcidades");
        }else{
            System.out.println(" gano" + b.getNombre() + " felcidades");
        }
        
    }
    
}
