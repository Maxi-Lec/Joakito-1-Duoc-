/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dueloheroes;

/**
 *
 * @author AL-Alumno
 */
public class Heroe {
    private String nombre;
    private int vida;
    private int ataque;
    
    //constructor

    public Heroe(String nombre, int vida, int ataque) {
        this.nombre = nombre;
        this.vida = vida;
        this.ataque = ataque;
    }

    //atacar
    public void atacar(Heroe rival){
        rival.setVida(rival.getVida() - ataque);
        
        if(rival.getVida() < 0){
            rival.setVida(0);
        }
        System.out.println(nombre +"ataca a" + rival.getNombre()+ " y le quita" + ataque + " de vida");
        System.out.println(rival.getNombre()+ " y tiene" + rival.getVida() + " de vida");
    }
    
    //comprobar si esta vivo
    public boolean estaVivo(){
        return vida > 0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }
    
}
