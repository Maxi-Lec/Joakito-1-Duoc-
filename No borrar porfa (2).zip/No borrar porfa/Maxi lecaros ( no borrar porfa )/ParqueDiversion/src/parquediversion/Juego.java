/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parquediversion;

/**
 *
 * @author AL-Alumno
 */
public class Juego {
    // atributos
    private String nombre;
    private int edadMinima;
    private int duracion;

    public Juego(String nombre, int edadMinima, int duracion) {
        this.nombre = nombre;
        this.edadMinima = edadMinima;
        this.duracion = duracion;
    }
    
    // mostrar informacion
    public void mostrarInfo(){
        System.out.println("Nombre:" + nombre);
        System.out.println("Edad minima:" + edadMinima);
        System.out.println("Nombre:" + duracion);
        System.out.println("----------------------");
        
    }

    public boolean puedeSubir(int edad){
        return edad >= edadMinima;
    }
}
