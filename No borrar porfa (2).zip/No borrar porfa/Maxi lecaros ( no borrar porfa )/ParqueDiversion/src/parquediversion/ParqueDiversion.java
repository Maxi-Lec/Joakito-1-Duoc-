/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parquediversion;

/**
 *
 * @author AL-Alumno
 */
public class ParqueDiversion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Juego juego1 = new Juego("Montaña Rusa", 12,3);
        Juego juego2 = new Juego("Carrusel", 5,5);
        Juego juego3 = new Juego("Casa Del Terro", 10,8);
        
        //mostrar informacion
        juego1.mostrarInfo();
        juego2.mostrarInfo();
        juego3.mostrarInfo();
        
        int edadNino = 10;
        System.out.println("¿Un niño de " + edadNino + "años puede subir a la montaña rusa?"+ juego1.puedeSubir(edadNino));
        System.out.println("¿Un niño de " + edadNino + "años puede subir al carrusel?"+ juego2.puedeSubir(edadNino));
        System.out.println("¿Un niño de " + edadNino + "años puede subir a la casa del terror?"+ juego3.puedeSubir(edadNino));
    }
    
}
