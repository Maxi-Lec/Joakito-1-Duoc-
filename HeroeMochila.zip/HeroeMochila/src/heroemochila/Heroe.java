/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heroemochila;
import java.util.ArrayList;
/**
 *
 * @author AL-Alumno
 */
public class Heroe {
    private String nombre;
    private int vida = 100;
    private ArrayList<String> mochila = new ArrayList<>();
    
    //constructor

    public Heroe(String nombre) {
        this.nombre = nombre;
    }
    //devolver vida
    public int getVida(){
        return vida;
    }
    
    //recibe daño
    public void recibirDanio( int d){
        vida -=d;
        
        //la vida nunca es menor de 0
        if (vida < 0){
            vida = 0;
        }
    }
    // cura al heroe
    public void curar ( int c){
        vida += c;
        
        // la vida no supera 100
        if (vida > 100)
            vida = 100;
    }
    
    // agrega objeto a la mochila
    // la mochila max 5 objetos
    public boolean agregarItem(String item){
        if ( mochila.size() < 5){
            mochila.add(item);
            return true;
        }
        return false;
    }
    
    // usa objeto de mochila
    public void usarItem(String item){
        if (mochila.contains(item)){
            mochila.remove(item);
            
            //pocion cura 30
            if (item.equalsIgnoreCase("Pocion")){
            curar(30);
        }
      }
    }
    
    //muestra estado
    public void mostrarEstado(){
        System.out.println("Nombre" + nombre);
        System.out.println("Vida" + vida);
        System.out.println("Mochila" + mochila);
    }
}
