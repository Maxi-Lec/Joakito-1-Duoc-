/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package heroemochila;
/**
 *
 * @author AL-Alumno
 */
public class HeroeMochila {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Heroe heroe = new Heroe("Javier");
        
        System.out.println("=== ESTADO INCIAL===");
        heroe.mostrarEstado();
        
        System.out.println("=== RECIBE 40 DE DAÑO");
        heroe.recibirDanio(40);
        heroe.mostrarEstado();
        
        System.out.println("=== AGREGA OBJETOS ===");
        
        System.out.println("Espada:" + heroe.agregarItem("Espada"));
        System.out.println("Escudo:" + heroe.agregarItem("Escudo"));
        System.out.println("Pocion:" + heroe.agregarItem("Pocion"));
        
        heroe.mostrarEstado();
        
        System.out.println("=== USA LA POCION ===");
        heroe.usarItem("Pocion");
        heroe.mostrarEstado();
        
        System.out.println("=== RECIBE 100 DAÑO");
        heroe.recibirDanio(100);
        heroe.mostrarEstado();
        
        //heroe se intenta curar
        System.out.println("=== SE CURA ==="
                + "");
        heroe.curar(30);
        heroe.mostrarEstado();
    }
    
}
